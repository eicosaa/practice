package dao;

public class BoardDao {
	public BoardDao() { } // -생성자 메소드
}
