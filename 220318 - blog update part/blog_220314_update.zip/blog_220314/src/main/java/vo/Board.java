package vo;

public class Board {
	public Board() { } // -생성자 메소드
	public int boardNo;
	public String categoryName;
	public String boardTitle;
	public String boardContent;
	public String boardPw;
	public String createDate;
	public String updateDate;
}
