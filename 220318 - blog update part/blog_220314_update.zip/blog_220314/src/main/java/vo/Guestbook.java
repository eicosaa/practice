package vo;

public class Guestbook {
	public Guestbook() { } // -생성자 메소드
	public int guestbookNo;
	public String guestbookContent;
	public String writer;
	public String createDate;
	public String updateDate;
	public String guestbookPw;
}
